package be.kdg.bejeweledtake2.model;

public enum GemColor {
    BLUE,
    GREEN,
    ORANGE,
    PINK,
    RED,
    WHITE,
    YELLOW,
    NONE
}


