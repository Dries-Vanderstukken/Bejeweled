package be.kdg.bejeweledtake2.model;

public enum GemMutation {
    BOMB,
    HYPER_CUBE,
    NONE
}
