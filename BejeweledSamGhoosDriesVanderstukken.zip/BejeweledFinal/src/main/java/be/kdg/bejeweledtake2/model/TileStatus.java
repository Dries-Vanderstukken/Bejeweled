package be.kdg.bejeweledtake2.model;

public enum TileStatus {
    SELECTED,
    POSSIBLE_MOVE,
    NONE,
    EMPTY,
}
